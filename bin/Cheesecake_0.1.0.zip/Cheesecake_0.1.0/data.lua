-- Technologies
-- require ("libs.tech-functions")

--- Items
require("prototypes.UraniumAxe.item")
require("prototypes.UraniumAxe.recipe")