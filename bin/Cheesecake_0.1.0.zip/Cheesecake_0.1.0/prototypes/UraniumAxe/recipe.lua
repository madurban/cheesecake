data:extend({

  {
    type = "recipe",
    name = "uranium-axe",
    enabled = true,
    ingredients =
    {
      {"steel-axe", 1},
      {"uranium-235", 42}
    },
    result = "uranium-axe",
    requester_paste_multiplier = 1
  },  
  
 })

