-- Technologies
require ("libs.technology")

--- Items
require("prototypes.UraniumAxe.item")
